<div class="footerbar sidebar footer-left">
    <?php if (function_exists('dynamic_sidebar')) dynamic_sidebar('Footer Widgets Left'); ?>
</div>
<div class="footerbar sidebar footer-center">
   <?php if (function_exists('dynamic_sidebar')) dynamic_sidebar('Footer Widgets Center'); ?>
</div>
<div class="footerbar sidebar footer-right">
   <?php if (function_exists('dynamic_sidebar')) dynamic_sidebar('Footer Widgets Right'); ?>
</div>
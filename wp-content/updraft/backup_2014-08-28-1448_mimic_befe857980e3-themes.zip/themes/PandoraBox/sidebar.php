<?php if ( is_active_sidebar( 'sidebar-blog' ) ) : ?>
    <aside class="sidebar">
        <div class="sidebar-container">
                <?php dynamic_sidebar( 'sidebar-blog' ); ?>
        </div>
    </aside>
<?php endif; ?>


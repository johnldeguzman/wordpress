<?php 
get_header(); 
?>

<div class="colorblock" id="bg"></div>
    <div class="block whiteblock blogblock">
        <div id="blog" class="block-container">
        <article class="post page single-page notfound">
            <h1>W P L O C K E R .C O M - 404</h1>
            <h4>Page not found.</h4>
            <div class="as-post"> <?php get_search_form(); ?> </div>
            </article>
        </div>
    </div>

<?php get_footer(); ?>
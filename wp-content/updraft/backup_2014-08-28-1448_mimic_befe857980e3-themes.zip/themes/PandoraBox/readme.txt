Theme Name: PandoraBox
Theme URI: iltaen.com/pandorabox
Description: Mobile Develop Onepage HTML Template
Author: iltaen
Author URI: http://themeforest.net/user/Iltaen
License: GNU General Public License
License URI: license.txt
Tags: green, white, flexible-width, one-column, custom-colors, featured-images, full-width-template, post-formats, sticky-post, theme-options
Version: 1.3.0
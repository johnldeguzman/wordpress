<?php

namespace OpenCloud\Identity\Constants;

class User 
{

    const MODE_NAME  = 'name';
    const MODE_EMAIL = 'email';
    const MODE_ID    = 'id';

} 
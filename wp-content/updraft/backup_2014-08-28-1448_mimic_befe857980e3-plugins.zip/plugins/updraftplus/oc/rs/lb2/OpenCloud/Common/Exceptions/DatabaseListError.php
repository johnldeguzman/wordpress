<?php

namespace OpenCloud\Common\Exceptions;

class DatabaseListError extends \Exception {}

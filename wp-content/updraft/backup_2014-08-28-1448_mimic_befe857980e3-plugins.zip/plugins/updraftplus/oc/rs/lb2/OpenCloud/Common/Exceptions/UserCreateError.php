<?php

namespace OpenCloud\Common\Exceptions;

class UserCreateError extends \Exception {}

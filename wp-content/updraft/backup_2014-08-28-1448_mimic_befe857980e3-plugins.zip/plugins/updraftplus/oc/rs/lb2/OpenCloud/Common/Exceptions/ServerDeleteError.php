<?php

namespace OpenCloud\Common\Exceptions;

class ServerDeleteError extends \Exception {}

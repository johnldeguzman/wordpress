<?php

namespace OpenCloud\Common\Exceptions;

class NoNameError extends \Exception {}

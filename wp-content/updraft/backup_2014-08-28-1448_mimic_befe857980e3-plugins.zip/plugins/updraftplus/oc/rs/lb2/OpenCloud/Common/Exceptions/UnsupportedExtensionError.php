<?php

namespace OpenCloud\Common\Exceptions;

class UnsupportedExtensionError extends \Exception {}

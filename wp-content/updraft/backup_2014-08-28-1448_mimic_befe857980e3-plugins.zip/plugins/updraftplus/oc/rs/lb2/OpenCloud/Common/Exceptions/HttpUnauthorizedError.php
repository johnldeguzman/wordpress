<?php

namespace OpenCloud\Common\Exceptions;

class HttpUnauthorizedError extends \Exception {}

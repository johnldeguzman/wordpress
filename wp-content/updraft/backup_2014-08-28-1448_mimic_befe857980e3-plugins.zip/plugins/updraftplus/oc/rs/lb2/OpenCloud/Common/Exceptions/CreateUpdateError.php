<?php

namespace OpenCloud\Common\Exceptions;

class CreateUpdateError extends \Exception {}

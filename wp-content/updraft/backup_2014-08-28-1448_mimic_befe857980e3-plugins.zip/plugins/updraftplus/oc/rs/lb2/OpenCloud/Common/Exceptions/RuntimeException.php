<?php

namespace OpenCloud\Common\Exceptions;

class RuntimeException extends \Exception {}
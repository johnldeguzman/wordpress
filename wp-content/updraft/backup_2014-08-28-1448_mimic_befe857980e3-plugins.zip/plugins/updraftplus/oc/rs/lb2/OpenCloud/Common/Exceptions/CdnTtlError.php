<?php

namespace OpenCloud\Common\Exceptions;

class CdnTtlError extends \Exception {}
